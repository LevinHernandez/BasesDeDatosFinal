prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>41540361828971974087
,p_default_application_id=>66754
,p_default_id_offset=>0
,p_default_owner=>'HANDLES'
);
wwv_flow_api.create_page(
 p_id=>6
,p_user_interface_id=>wwv_flow_api.id(3978529220356837870)
,p_name=>'Test'
,p_alias=>'TEST'
,p_step_title=>'Test'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'LEVIN'
,p_last_upd_yyyymmddhh24miss=>'20201022042326'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3987820273985145298)
,p_plug_name=>'Test'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3978418891637837783)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'CENTROS'
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_api.create_card(
 p_id=>wwv_flow_api.id(3987820749842145299)
,p_region_id=>wwv_flow_api.id(3987820273985145298)
,p_layout_type=>'FLOAT'
,p_title_adv_formatting=>false
,p_title_column_name=>'DEPARTAMENTO'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'DIRECCION'
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_api.component_end;
end;
/
