prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>41540361828971974087
,p_default_application_id=>66754
,p_default_id_offset=>0
,p_default_owner=>'HANDLES'
);
wwv_flow_api.create_page(
 p_id=>15
,p_user_interface_id=>wwv_flow_api.id(3978529220356837870)
,p_name=>'Sucursales'
,p_alias=>'SUCURSALES1'
,p_step_title=>'Sucursales'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'LEVIN'
,p_last_upd_yyyymmddhh24miss=>'20201029234241'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6212412517906554839)
,p_plug_name=>'Informe 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3978442148727837800)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'CENTROS'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Informe 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6212412905834554839)
,p_name=>'Informe 1'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:43:&SESSION.::&DEBUG.:RP:P43_IDCENTRO:\#IDCENTRO#\'
,p_detail_link_text=>'<span aria-label="Editar"><span class="fa fa-edit" aria-hidden="true" title="Editar"></span></span>'
,p_owner=>'LEVIN'
,p_internal_uid=>6212412905834554839
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6212413099264554840)
,p_db_column_name=>'IDCENTRO'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID Sucursal'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6212413452194554842)
,p_db_column_name=>'DEPARTAMENTO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6212413841976554843)
,p_db_column_name=>'DIRECCION'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Direccion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6212414201385554843)
,p_db_column_name=>'TELEFONO'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Telefono'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6213702559893581767)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'62137026'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IDCENTRO:DEPARTAMENTO:DIRECCION:TELEFONO'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6212417448553559083)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(6212412517906554839)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(3978506564960837851)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Crear'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:43:&SESSION.::&DEBUG.:43'
);
wwv_flow_api.component_end;
end;
/
