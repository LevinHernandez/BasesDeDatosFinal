prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>41540361828971974087
,p_default_application_id=>66754
,p_default_id_offset=>0
,p_default_owner=>'HANDLES'
);
wwv_flow_api.create_page(
 p_id=>5
,p_user_interface_id=>wwv_flow_api.id(3978529220356837870)
,p_name=>'informes preliminar'
,p_alias=>'INFORMES-PRELIMINAR'
,p_step_title=>'informes preliminar'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(3978532416433837880)
,p_html_page_header=>'UMG 4'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'JSICAJAL1@MIUMG.EDU.GT'
,p_last_upd_yyyymmddhh24miss=>'20201022043920'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3987369951279151871)
,p_plug_name=>'informes preliminar'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(3978444069057837802)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select IDCENTRO,',
'       DEPARTAMENTO,',
'       DIRECCION,',
'       TELEFONO',
'  from CENTROS'))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_no_data_found=>'Not Found 404'
,p_attribute_01=>'DIVIDER:INSET'
,p_attribute_02=>'DEPARTAMENTO'
,p_attribute_06=>'DEPARTAMENTO'
,p_attribute_08=>'DIRECCION'
,p_attribute_14=>'TELEFONO'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(3986356552874072510)
,p_name=>'P5_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(3987369951279151871)
,p_prompt=>'Visualizacion de Datos'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>'select * from centros;'
,p_field_template=>wwv_flow_api.id(3978505497352837850)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.component_end;
end;
/
