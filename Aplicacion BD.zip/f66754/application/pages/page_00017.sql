prompt --application/pages/page_00017
begin
--   Manifest
--     PAGE: 00017
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>41540361828971974087
,p_default_application_id=>66754
,p_default_id_offset=>0
,p_default_owner=>'HANDLES'
);
wwv_flow_api.create_page(
 p_id=>17
,p_user_interface_id=>wwv_flow_api.id(3978529220356837870)
,p_name=>'Pagos'
,p_alias=>'PAGOS'
,p_step_title=>'Pagos'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'VALERY'
,p_last_upd_yyyymmddhh24miss=>'20201029021744'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5864548091359337070)
,p_plug_name=>'Informe 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3978442148727837800)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'PAGOS'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Informe 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(5864548494606337071)
,p_name=>'Informe 1'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:RP:P18_ID_PAGO:\#ID_PAGO#\'
,p_detail_link_text=>'<span aria-label="Editar"><span class="fa fa-edit" aria-hidden="true" title="Editar"></span></span>'
,p_owner=>'VALERY'
,p_internal_uid=>5864548494606337071
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5864548551659337071)
,p_db_column_name=>'ID_PAGO'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id Pago'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5864548914127337072)
,p_db_column_name=>'FEC_PAGO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Fecha de pago'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5864549332384337072)
,p_db_column_name=>'IDPROVEEDOR'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Idproveedor'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5864549712005337072)
,p_db_column_name=>'NUM_FACT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'No. de factura'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5864550118780337073)
,p_db_column_name=>'VALORPAGADO'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Cantidad pagada'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(5865930825438781949)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'58659309'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_PAGO:FEC_PAGO:IDPROVEEDOR:NUM_FACT:VALORPAGADO'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5864560841432345050)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(5864548091359337070)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(3978506564960837851)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Registrar nuevo pago'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:18'
);
wwv_flow_api.component_end;
end;
/
