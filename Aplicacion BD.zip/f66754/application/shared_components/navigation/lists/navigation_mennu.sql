prompt --application/shared_components/navigation/lists/navigation_mennu
begin
--   Manifest
--     LIST: Navigation Mennu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>41540361828971974087
,p_default_application_id=>66754
,p_default_id_offset=>0
,p_default_owner=>'HANDLES'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(4699024400508275162)
,p_name=>'Navigation Mennu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(4699025040811275163)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Laboratorios'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(4699025449982275163)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Proveedores'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(4699025887180275164)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Aseguradoras'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(4699026295945275164)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Centros'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(4699026650127275164)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Citas'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(4699027077848275165)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Medicos'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(4699027456135275165)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Especialidades'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
